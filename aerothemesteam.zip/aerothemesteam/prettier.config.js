/** @type {import("prettier").Config} */
export default {
	useTabs: true,
};
