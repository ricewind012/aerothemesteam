/** @type {import("steam-theming-utils").Config} */
export default {
	ignore: [
		"clientshared",
		"client/popups/contextmenus/friendsui",
		"client/shared",
	],
};
